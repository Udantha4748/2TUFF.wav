2TUFF.wav - a homebrew music player for the Sony PSP
====================================================

INSTALL

1. Copy the "PSP" folder from this archive onto the :\PSP\GAME in your Memory
   Stick, so you end up with:

       ms0:/PSP/GAME/2TUFFwav/EBOOT.PBP

   (On a PSP Go using internal storage: ef0:/PSP/GAME/2TUFFwav/EBOOT.PBP)

2. Put your music as .mp3 files under:

       ms0:/MUSIC/

   - one sub-folder per album, and/or
   - .m3u / .m3u8 / .pls playlists, and/or
   - loose .mp3 files (these show up under "UNSORTED").

   Optional, per album folder: a cover image named cover.jpg / folder.jpg /
   front.jpg / albumart.jpg.
   Optional, per track: an .lrc file with the same name for synced lyrics.

3. Launch "2TUFF.wav" from the PSP Game menu.

Your settings (theme / font / cover style) are saved next to the EBOOT and
restored the next time you launch.

A PSP able to run homebrew (custom firmware or equivalent) is required.
